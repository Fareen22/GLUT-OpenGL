/*
 * GLUT Shapes Demo

 */

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include<windows.h>
#include <GL/glut.h>
#endif

#include <stdlib.h>

static void resize(int width, int height)
{
    const float ar = (float) width / (float) height;

    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-ar, ar, -1.0, 1.0, 3.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}

static void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);





     glBegin(GL_POLYGON);//Right Side for Red


        glColor3d(139,0,0);
        glVertex3f(2,3,-20);

        glColor3d(139,0,0);
        glVertex3f(2,-3,-20);

          glColor3d(139,0,0);
        glVertex3f(6,-3,-20);

          glColor3d(139,0,0);
        glVertex3f(6,3,-20);


    glEnd();
    glBegin(GL_POLYGON);//Left Side For Blue


        glColor3d(0,0,139);
        glVertex3f(2,-3,-20);

        glColor3d(0,0,139);
        glVertex3f(2,3,-20);

          glColor3d(0,0,139);
        glVertex3f(-6,3,-20);

          glColor3d(0,0,139);
        glVertex3f(-6,-3,-20);


    glEnd();
   /* glBegin(GL_POLYGON);//uporer part


        glColor3d(139,0,0);
        glVertex3f(-2,-3,-20);//1st

        glColor3d(139,0,0);
        glVertex3f(-2,3,-20);//2nd

          glColor3d(0,0,128);
        glVertex3f(-6,-3,-20);//3rd

          glColor3d(0,0,128);
        glVertex3f(-6,3,-20);//4th


    glEnd();*/
     glBegin(GL_POLYGON);//Middle part for White


        glColor3d(255,255,255);
        glVertex3f(2,3,-20);

        glColor3d(255,255,255);
        glVertex3f(2,-3,-20);

          glColor3d(255,255,255);
        glVertex3f(-2,-3,-20);

           glColor3d(255,255,255);
        glVertex3f(-2,3,-20);


    glEnd();










    glutSwapBuffers();
}


/*static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27 :
    case 'q':
        exit(0);
        break;
    }
    glutPostRedisplay();
}

static void idle(void)
{
    glutPostRedisplay();
}*/

/* Program entry point */
int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitWindowSize(640,480);
    glutInitWindowPosition(10,10);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);

    glutCreateWindow("Flag of FRANCE");

    glutReshapeFunc(resize);
    glutDisplayFunc(display);


    glClearColor(0,0,0,0);

    glutMainLoop();

    return 0;
}
//glutKeyboardFunc(key);
    //glutIdleFunc(idle);

 //glMatrixMode(GL_PROJECTION);
